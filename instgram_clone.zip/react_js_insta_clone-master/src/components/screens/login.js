import React from 'react'

const Login=()=>{
	return (
	<div className="mycard">
		<div className="card auth-card">
				<h2>Insagram</h2>
				<input type="text" placeholder="email" />
				<input type="password" placeholder=""/>
			 	<button class="btn waves-effect waves-light #64b5f6 blue lighten-2" type="submit" name="action">Login</button>
		</div>
	</div>
		)
}


export default  Login