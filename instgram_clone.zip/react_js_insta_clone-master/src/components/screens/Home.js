import React from 'react'

const Home=()=>{
	return (
		//<h1>Home</h1>
		<div className="home">
			<div  className="card home-card">
				<h5>Yogify Your Life</h5>
				<div className="card-image"></div>
					<img src="https://scontent.fjai2-1.fna.fbcdn.net/v/t1.0-9/116645397_831194191010495_3531731952557402213_n.jpg?_nc_cat=107&_nc_sid=09cbfe&_nc_ohc=nZXoVoFwDEQAX9dTjIR&_nc_ht=scontent.fjai2-1.fna&oh=f75e076a1d3942021dbd05b1261aea06&oe=5F5193D6" />
					<div className="card-content">
					 <i class="material-icons">favorite</i>
					<h6>asana</h6>
					<p>Greate initiative by sadguru</p>
					<input text="type" placeholder="add comment"/>
				</div>
			</div>
			<div  className="card home-card">
				<h5>Yogify Your Life</h5>
				<div className="card-image"></div>
					<img src="https://scontent.fjai2-2.fna.fbcdn.net/v/t1.0-9/116470069_773063076838048_7668019836248948966_o.jpg?_nc_cat=109&_nc_sid=8bfeb9&_nc_ohc=d8zNczEGYpkAX_en8bN&_nc_ht=scontent.fjai2-2.fna&oh=3c01831b2e5f17790ea5b8195d6a2fe5&oe=5F513DC1" />
					<div className="card-content">
					 <i class="material-icons">favorite</i>
					<h6>asana</h6>
					<p>Greate initiative by sadguru</p>
					<input text="type" placeholder="add comment"/>
				</div>
			</div>
			<div  className="card home-card">
				<h5>Yogify Your Life</h5>
				<div className="card-image"></div>
					<img src="https://scontent.fjai2-1.fna.fbcdn.net/v/t1.0-0/p206x206/21687658_1865891653725511_6956133069080098037_n.jpg?_nc_cat=107&_nc_sid=da31f3&_nc_ohc=2Hgceh83BqAAX9i9yO8&_nc_ht=scontent.fjai2-1.fna&_nc_tp=6&oh=12846f247b159c3453d6e045b1954d66&oe=5F5174CD" />
					<div className="card-content">
					 <i class="material-icons">favorite</i>
					<h6>asana</h6>
					<p>Greate initiative by sadguru</p>
					<input text="type" placeholder="add comment"/>
				</div>
			</div>
			<div  className="card home-card">
				<h5>Yogify Your Life</h5>
				<div className="card-image"></div>
					<img src="https://scontent.fjai2-1.fna.fbcdn.net/v/t1.0-0/p600x600/116687308_357757635234593_2719760897683935469_n.jpg?_nc_cat=105&_nc_sid=8bfeb9&_nc_ohc=6Z5uqifX6ToAX9v-XTl&_nc_ht=scontent.fjai2-1.fna&_nc_tp=6&oh=8c9a81966ce028d000126c2df5baa402&oe=5F4F3AA7" />
					<div className="card-content">
					 <i class="material-icons">favorite</i>
					<h6>asana</h6>
					<p>Greate initiative by sadguru</p>
					<input text="type" placeholder="add comment"/>
				</div>
			</div>
			<div  className="card home-card">
				<h5>Yogify Your Life</h5>
				<div className="card-image"></div>
					<img src="https://scontent.fjai2-2.fna.fbcdn.net/v/t1.0-0/p206x206/51146966_1951041461688809_8264937457548525568_n.jpg?_nc_cat=101&_nc_sid=da31f3&_nc_ohc=8u0oPZ1gIokAX-fm8UY&_nc_ht=scontent.fjai2-2.fna&_nc_tp=6&oh=e7bd01af0537aa8a91ba741e0831f1bc&oe=5F4E917A" />
					<div className="card-content">
					 <i class="material-icons">favorite</i>
					<h6>asana</h6>
					<p>Greate initiative by sadguru</p>
					<input text="type" placeholder="add comment"/>
				</div>
			</div>
			<div  className="card home-card">
				<h5>Yogify Your Life</h5>
				<div className="card-image"></div>
					<img src="https://scontent.fjai2-2.fna.fbcdn.net/v/t1.0-0/c62.0.206.206a/p206x206/51007121_1951042545022034_1145451688895709184_n.jpg?_nc_cat=100&_nc_sid=da31f3&_nc_ohc=q4-E_Trg9uQAX8op59p&_nc_ht=scontent.fjai2-2.fna&oh=c6acde09151883396310fb744e16cb6c&oe=5F510C9C" />
					<div className="card-content">
					 <i class="material-icons">favorite</i>
					<h6>asana</h6>
					<p>Greate initiative by sadguru</p>
					<input text="type" placeholder="add comment"/>
				</div>
			</div>
			<div  className="card home-card">
				<h5>Yogify Your Life</h5>
				<div className="card-image"></div>
					<img src="https://scontent.fjai2-2.fna.fbcdn.net/v/t1.0-9/99253666_904228463358968_8966956570818641920_o.jpg?_nc_cat=110&_nc_sid=ad2b24&_nc_ohc=C5sjnQDsHsoAX_2oNEl&_nc_ht=scontent.fjai2-2.fna&oh=db4d2fb8fb0821fa8a77510fded88151&oe=5F4F687B" />
					<div className="card-content">
					 <i class="material-icons">favorite</i>
					<h6>asana</h6>
					<p>Greate initiative by sadguru</p>
					<input text="type" placeholder="add comment"/>
				</div>
			</div>
			<div  className="card home-card">
				<h5>Yogify Your Life</h5>
				<div className="card-image"></div>
					<img src="https://scontent.fjai1-2.fna.fbcdn.net/v/t31.0-8/28618752_2031890790413879_5255312442999699176_o.jpg?_nc_cat=102&_nc_sid=e3f864&_nc_ohc=UValZ3bLN2kAX-RYdsQ&_nc_ht=scontent.fjai1-2.fna&oh=a292803bfc2b687a3709fdb442925153&oe=5F51464C" />
					<div className="card-content">
					 <i class="material-icons">favorite</i>
					<h6>asana</h6>
					<p>Greate initiative by sadguru</p>
					<input text="type" placeholder="add comment"/>
				</div>
			</div>
			<div  className="card home-card">
				<h5>Yogify Your Life</h5>
				<div className="card-image"></div>
					<img src="https://scontent.fjai1-1.fna.fbcdn.net/v/t1.0-0/p526x296/116264206_3696039710410239_6835156450277884020_n.jpg?_nc_cat=101&_nc_sid=8bfeb9&_nc_ohc=7yS8RX41FXUAX81B3iD&_nc_ht=scontent.fjai1-1.fna&_nc_tp=6&oh=94586e87fac707ead549bde525219af7&oe=5F52CEF3" />
					<div className="card-content">
					 <i class="material-icons">favorite</i>
					<h6>asana</h6>
					<p>Greate initiative by sadguru</p>
					<input text="type" placeholder="add comment"/>
				</div>
			</div>
		</div>
		)
}


export default  Home